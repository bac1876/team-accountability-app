# IMPORTANT PROJECT NOTES

## ⚠️ PASSWORD POLICY ⚠️

**DO NOT CHANGE USER PASSWORDS UNLESS EXPLICITLY REQUESTED**

- User has had to reset passwords multiple times due to unauthorized changes
- Only modify passwords when specifically asked to do so
- Current admin password should remain as set by user
- Do not modify authentication credentials during bug fixes or feature additions

## Current Authentication
- Admin user: brian@searchnwa.com
- Password: [DO NOT MODIFY WITHOUT REQUEST]
- All SearchNWA team members use: temp123
- Demo users: john123, jane123

## Development Guidelines
- Fix bugs without touching authentication
- Add features without modifying existing user credentials
- Always preserve existing login functionality

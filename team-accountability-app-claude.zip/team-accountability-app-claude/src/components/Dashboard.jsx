import { useState, useEffect } from 'react'
import { format, startOfWeek, endOfWeek } from 'date-fns'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { CheckCircle, Circle, Clock, Target, MessageSquare, TrendingUp } from 'lucide-react'
import { userDataStore } from '../utils/dataStore.js'
import PhoneCallTracking from './PhoneCallTracking.jsx'
import DailyFocus from './DailyFocus.jsx'

const Dashboard = ({ user }) => {
  const [todayCommitment, setTodayCommitment] = useState('')
  const [commitmentStatus, setCommitmentStatus] = useState('pending')
  const [weeklyGoals, setWeeklyGoals] = useState([])
  const [newGoal, setNewGoal] = useState('')
  const [reflection, setReflection] = useState({
    wentWell: '',
    differently: '',
    needHelp: ''
  })
  const [recentCommitments, setRecentCommitments] = useState([])
  const [userData, setUserData] = useState(null)
  const [completionRate, setCompletionRate] = useState(0)

  const today = new Date()
  const todayString = today.toISOString().split('T')[0]
  const weekStart = startOfWeek(today)
  const weekEnd = endOfWeek(today)

  // Load user data from persistent storage
  useEffect(() => {
    if (user?.id) {
      const data = userDataStore.getUserData(user.id)
      setUserData(data)
      
      // Load today's commitment
      const todayCommit = data.commitments.find(c => c.date === todayString)
      if (todayCommit) {
        setTodayCommitment(todayCommit.text)
        setCommitmentStatus(todayCommit.status)
      }

      // Load weekly goals
      const currentWeekGoals = data.goals.filter(g => {
        const goalDate = new Date(g.createdAt)
        return goalDate >= weekStart && goalDate <= weekEnd
      })
      setWeeklyGoals(currentWeekGoals)

      // Load recent commitments (last 7 days)
      const recentCommits = data.commitments
        .filter(c => {
          const commitDate = new Date(c.date)
          const daysDiff = (today - commitDate) / (1000 * 60 * 60 * 24)
          return daysDiff <= 7
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date))
      setRecentCommitments(recentCommits)

      // Calculate completion rate
      const completedCommits = recentCommits.filter(c => c.status === 'completed').length
      const rate = recentCommits.length > 0 ? (completedCommits / recentCommits.length) * 100 : 0
      setCompletionRate(Math.round(rate))

      // Load reflection for today
      const todayReflection = data.reflections.find(r => r.date === todayString)
      if (todayReflection) {
        setReflection(todayReflection)
      }
    }
  }, [user, todayString, weekStart, weekEnd])

  const saveCommitment = () => {
    if (!todayCommitment.trim()) return

    const commitmentData = {
      id: Date.now().toString(),
      text: todayCommitment,
      date: todayString,
      status: commitmentStatus,
      createdAt: new Date().toISOString()
    }

    userDataStore.addCommitment(user.id, commitmentData)
    
    // Refresh data
    const updatedData = userDataStore.getUserData(user.id)
    setUserData(updatedData)
  }

  const addWeeklyGoal = () => {
    if (!newGoal.trim()) return

    const goalData = {
      id: Date.now().toString(),
      text: newGoal,
      completed: false,
      createdAt: new Date().toISOString()
    }

    userDataStore.addGoal(user.id, goalData)
    setNewGoal('')
    
    // Refresh goals
    const updatedData = userDataStore.getUserData(user.id)
    const currentWeekGoals = updatedData.goals.filter(g => {
      const goalDate = new Date(g.createdAt)
      return goalDate >= weekStart && goalDate <= weekEnd
    })
    setWeeklyGoals(currentWeekGoals)
  }

  const toggleGoalCompletion = (goalId) => {
    userDataStore.toggleGoalCompletion(user.id, goalId)
    
    // Refresh goals
    const updatedData = userDataStore.getUserData(user.id)
    const currentWeekGoals = updatedData.goals.filter(g => {
      const goalDate = new Date(g.createdAt)
      return goalDate >= weekStart && goalDate <= weekEnd
    })
    setWeeklyGoals(currentWeekGoals)
  }

  const saveReflection = () => {
    const reflectionData = {
      id: Date.now().toString(),
      date: todayString,
      wentWell: reflection.wentWell,
      differently: reflection.differently,
      needHelp: reflection.needHelp,
      createdAt: new Date().toISOString()
    }

    userDataStore.addReflection(user.id, reflectionData)
  }

  const updateCommitmentStatus = (status) => {
    setCommitmentStatus(status)
    if (todayCommitment.trim()) {
      const commitmentData = {
        id: Date.now().toString(),
        text: todayCommitment,
        date: todayString,
        status: status,
        createdAt: new Date().toISOString()
      }
      userDataStore.addCommitment(user.id, commitmentData)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user?.name || user?.username}!</h1>
          <p className="text-gray-600">Track your daily commitments and achieve your goals</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Target className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                  <p className="text-2xl font-bold text-gray-900">{completionRate}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Weekly Goals</p>
                  <p className="text-2xl font-bold text-gray-900">{weeklyGoals.filter(g => g.completed).length}/{weeklyGoals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-8 w-8 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Recent Commits</p>
                  <p className="text-2xl font-bold text-gray-900">{recentCommitments.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="commitment" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="commitment">Today's Commitment</TabsTrigger>
            <TabsTrigger value="goals">Weekly Goals</TabsTrigger>
            <TabsTrigger value="reflection">Daily Reflection</TabsTrigger>
            <TabsTrigger value="calls">Phone Calls</TabsTrigger>
            <TabsTrigger value="focus">Daily Focus</TabsTrigger>
          </TabsList>

          {/* Today's Commitment Tab */}
          <TabsContent value="commitment" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Today's Commitment</span>
                </CardTitle>
                <CardDescription>
                  What's your main focus for today? Set a clear, achievable commitment.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Enter your commitment for today..."
                  value={todayCommitment}
                  onChange={(e) => setTodayCommitment(e.target.value)}
                  className="min-h-[100px]"
                />
                
                <div className="flex items-center space-x-4">
                  <div className="flex space-x-2">
                    <Button
                      variant={commitmentStatus === 'pending' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => updateCommitmentStatus('pending')}
                    >
                      <Clock className="h-4 w-4 mr-1" />
                      Pending
                    </Button>
                    <Button
                      variant={commitmentStatus === 'completed' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => updateCommitmentStatus('completed')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Completed
                    </Button>
                  </div>
                  
                  <Button onClick={saveCommitment} className="ml-auto">
                    Save Commitment
                  </Button>
                </div>

                {commitmentStatus && (
                  <div className="mt-4">
                    <Badge 
                      variant={commitmentStatus === 'completed' ? 'default' : 'secondary'}
                      className={commitmentStatus === 'completed' ? 'bg-green-100 text-green-800' : ''}
                    >
                      Status: {commitmentStatus === 'completed' ? 'Completed' : 'Pending'}
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Commitments */}
            {recentCommitments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Recent Commitments</CardTitle>
                  <CardDescription>Your commitments from the past week</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentCommitments.slice(0, 5).map((commit) => (
                      <div key={commit.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div className="flex-shrink-0 mt-1">
                          {commit.status === 'completed' ? (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          ) : (
                            <Circle className="h-5 w-5 text-gray-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900">{commit.text}</p>
                          <p className="text-xs text-gray-500">{format(new Date(commit.date), 'MMM d, yyyy')}</p>
                        </div>
                        <Badge 
                          variant={commit.status === 'completed' ? 'default' : 'secondary'}
                          className={commit.status === 'completed' ? 'bg-green-100 text-green-800' : ''}
                        >
                          {commit.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Weekly Goals Tab */}
          <TabsContent value="goals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Weekly Goals</span>
                </CardTitle>
                <CardDescription>
                  Set and track your goals for this week ({format(weekStart, 'MMM d')} - {format(weekEnd, 'MMM d')})
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Textarea
                    placeholder="Add a new weekly goal..."
                    value={newGoal}
                    onChange={(e) => setNewGoal(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={addWeeklyGoal} className="self-start">
                    Add Goal
                  </Button>
                </div>

                {weeklyGoals.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">This Week's Goals</h4>
                    {weeklyGoals.map((goal) => (
                      <div key={goal.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                        <button
                          onClick={() => toggleGoalCompletion(goal.id)}
                          className="flex-shrink-0 mt-1"
                        >
                          {goal.completed ? (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          ) : (
                            <Circle className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                          )}
                        </button>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium ${goal.completed ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                            {goal.text}
                          </p>
                          <p className="text-xs text-gray-500">
                            Added {format(new Date(goal.createdAt), 'MMM d, yyyy')}
                          </p>
                        </div>
                        <Badge 
                          variant={goal.completed ? 'default' : 'secondary'}
                          className={goal.completed ? 'bg-green-100 text-green-800' : ''}
                        >
                          {goal.completed ? 'Completed' : 'In Progress'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}

                {weeklyGoals.length > 0 && (
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>Progress</span>
                      <span>{weeklyGoals.filter(g => g.completed).length} of {weeklyGoals.length} completed</span>
                    </div>
                    <Progress 
                      value={weeklyGoals.length > 0 ? (weeklyGoals.filter(g => g.completed).length / weeklyGoals.length) * 100 : 0} 
                      className="h-2"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Daily Reflection Tab */}
          <TabsContent value="reflection" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>Daily Reflection</span>
                </CardTitle>
                <CardDescription>
                  Take a moment to reflect on your day and plan for tomorrow
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">What went well today?</label>
                  <Textarea
                    placeholder="Reflect on your successes and positive moments..."
                    value={reflection.wentWell}
                    onChange={(e) => setReflection({...reflection, wentWell: e.target.value})}
                    className="min-h-[80px]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">What would you do differently?</label>
                  <Textarea
                    placeholder="Think about areas for improvement..."
                    value={reflection.differently}
                    onChange={(e) => setReflection({...reflection, differently: e.target.value})}
                    className="min-h-[80px]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">What help or support do you need?</label>
                  <Textarea
                    placeholder="Identify resources or support you might need..."
                    value={reflection.needHelp}
                    onChange={(e) => setReflection({...reflection, needHelp: e.target.value})}
                    className="min-h-[80px]"
                  />
                </div>

                <Button onClick={saveReflection} className="w-full">
                  Save Reflection
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Phone Calls Tab */}
          <TabsContent value="calls">
            <PhoneCallTracking user={user} />
          </TabsContent>

          {/* Daily Focus Tab */}
          <TabsContent value="focus">
            <DailyFocus user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default Dashboard

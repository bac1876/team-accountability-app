import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import './App.css'

// Import components (we'll create these)
import LoginPage from './components/LoginPage'
import Dashboard from './components/Dashboard'
import AdminDashboard from './components/AdminDashboard'
import Navigation from './components/Navigation'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  // Check for existing session on app load
  useEffect(() => {
    // No localStorage - user must login each time
    setLoading(false)
  }, [])

  const login = (userData) => {
    setUser(userData)
    // No localStorage persistence
  }

  const logout = () => {
    setUser(null)
    // No localStorage cleanup needed
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background dark">
        <div className="text-lg text-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <Router>
      <div className="min-h-screen bg-background dark">
        {user && <Navigation user={user} onLogout={logout} />}
        
        <Routes>
          <Route 
            path="/login" 
            element={
              user ? <Navigate to="/" replace /> : <LoginPage onLogin={login} />
            } 
          />
          
          <Route 
            path="/" 
            element={
              user ? (
                user.role === 'admin' ? 
                  <AdminDashboard user={user} /> : 
                  <Dashboard user={user} />
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          
          <Route 
            path="/dashboard" 
            element={
              user ? 
                <Dashboard key="dashboard" user={user} /> : 
                <Navigate to="/login" replace />
            } 
          />
          
          <Route 
            path="/admin" 
            element={
              user && user.role === 'admin' ? 
                <AdminDashboard key="admin" user={user} /> : 
                <Navigate to="/" replace />
            } 
          />
        </Routes>
      </div>
    </Router>
  )
}

export default App
